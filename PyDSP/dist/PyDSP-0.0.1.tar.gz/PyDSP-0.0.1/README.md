## Navigate to Package

cd ./PyDSP

## Resolve Dependencies

python3 setup.py develop

## Package

python3 setup.py sdist

## Install

pip3 install ./dist/PyDSP-0.0.1.tar.gz
